# 来源
[session_start()&bestphp](https://www.anquanke.com/post/id/164569)
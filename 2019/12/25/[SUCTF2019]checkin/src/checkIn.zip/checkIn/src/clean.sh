#!/bin/bash
rm -rf /var/lib/php/sessions/*
rm -rf /app/uploads/*
